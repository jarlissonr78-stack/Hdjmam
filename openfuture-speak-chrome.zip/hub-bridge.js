/* Content script em openfuture.lol — ponte entre a pagina do hub e a extensao.
 * A pagina do hub nao fala direto com a extensao; ela manda window.postMessage e esta
 * ponte repassa pro background e devolve a resposta. Assim a pagina do Speak sabe se a
 * extensao esta instalada, passa o codigo de vinculo e controla o solver.
 */
(function () {
  var api = (typeof browser !== 'undefined') ? browser : chrome;

  // marca o DOM (deteccao sincrona e confiavel pela pagina, sem depender de mensagem)
  function mark() { try { document.documentElement.setAttribute('data-ofspeak-ext', '1'); } catch (e) { /* */ } }
  mark();
  document.addEventListener('DOMContentLoaded', mark);

  // ensina o hub (origin desta pagina) pro background — funciona no preview e em producao
  try { api.runtime.sendMessage({ type: 'hub-origin', origin: location.origin }); } catch (e) { /* */ }

  // anuncia instalada (a pagina escuta isso pra mostrar "extensao ok")
  function announce() { try { window.postMessage({ __ofspeak: 'installed', version: '1.0.0' }, location.origin); } catch (e) {} }
  announce();
  document.addEventListener('DOMContentLoaded', announce);

  window.addEventListener('message', function (e) {
    if (e.source !== window || !e.data || typeof e.data.__ofspeak_req === 'undefined') return;
    var req = e.data.__ofspeak_req, id = e.data.id;
    if (!req || !req.type) return;
    try {
      api.runtime.sendMessage(req, function (resp) {
        window.postMessage({ __ofspeak_res: resp || { ok: false }, id: id }, location.origin);
      });
    } catch (err) {
      window.postMessage({ __ofspeak_res: { ok: false, error: String(err && err.message) }, id: id }, location.origin);
    }
  });
})();
