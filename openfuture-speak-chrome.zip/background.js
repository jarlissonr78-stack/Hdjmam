/* OpenFuture Speak — background (service worker no Chrome / event page no Firefox).
 * MODELO RELE: a extensao NAO tem solver. Ela so:
 *   1) captura os tokens do Speak (Bearer access + X-Ef-Access account) via webRequest — ficam no aparelho.
 *   2) executa os fetches que o HUB mandar (via /rpc) no IP do aluno (catalyst IP-locked),
 *      injetando os tokens dela. O cerebro (o que resolve) fica no hub. Nada de logica aqui.
 */
const api = (typeof browser !== 'undefined') ? browser : chrome;
const IS_CHROME = (typeof browser === 'undefined');

// ---------- storage helpers ----------
function sget(keys) { return new Promise((r) => api.storage.local.get(keys, r)); }
function sset(obj) { return new Promise((r) => api.storage.local.set(obj, r)); }
function sleep(ms) { return new Promise((r) => setTimeout(r, ms)); }
// hub aprendido pela pagina (hub-bridge manda a origin). Default producao.
async function getHub() { const s = await sget(['hubOrigin']); return s.hubOrigin || 'https://openfuture.lol'; }

// ---------- catalyst (so pra diagnostico; vai sozinho como cookie SameSite=None) ----------
function readCatalyst() {
  return new Promise((res) => {
    try {
      api.cookies.getAll({ domain: 'better.efekta.com', name: 'catalyst_token' }, (cookies) => {
        let best = null;
        for (const c of (cookies || [])) if (c && c.value && c.value.length > 80 && (!best || c.value.length > best.length)) best = c.value;
        res(best);
      });
    } catch (e) { res(null); }
  });
}

// ---------- fingerprint da conta (pra detectar troca de conta) ----------
function _hash(s) { let h = 5381; for (let i = 0; i < s.length; i++) { h = ((h << 5) + h + s.charCodeAt(i)) >>> 0; } return String(h); }
function acctId(jwt) {
  try { const p = jwt.split('.')[1]; if (p) { const j = JSON.parse(atob(p.replace(/-/g, '+').replace(/_/g, '/'))); const id = String(j.sub || j.account || j.accountId || j.aid || j.uid || ''); if (id) return id; } } catch (e) { /* */ }
  return _hash(jwt).slice(0, 16);
}

// ---------- captura de tokens via webRequest ----------
// access_token (Bearer 71 chars) e account_jwt (X-Ef-Access JWT) sao HEADERS das chamadas /gap/bff.
function _onHeaders(details) {
  try {
    let auth = null, xef = null;
    for (const h of (details.requestHeaders || [])) {
      const n = (h.name || '').toLowerCase();
      if (n === 'authorization' && h.value && /^bearer /i.test(h.value)) auth = h.value.replace(/^bearer /i, '').trim();
      else if (n === 'x-ef-access' && h.value) xef = h.value.trim();
    }
    const url = details.url || '';
    if (auth && xef && /learn\.better\.efekta\.com/.test(url)) {
      sset({ accessToken: auth, accountJwt: xef, acct: acctId(xef), connected: true, tokAt: Date.now() }).then(maybeLink);
    } else if (auth && !xef && /study\.better\.efekta\.com/.test(url)) {
      sset({ accountJwt: auth, acct: acctId(auth) }).then(maybeLink);
    }
  } catch (e) { /* */ }
}
try {
  const extra = ['requestHeaders'].concat(IS_CHROME ? ['extraHeaders'] : []);
  api.webRequest.onSendHeaders.addListener(_onHeaders, { urls: ['https://*.better.efekta.com/*'] }, extra);
} catch (e) { /* */ }

// ---------- Origin override (pro fetch do SW passar no backend do Efekta) ----------
const EF_ORIGIN = 'https://lesson-player.study.better.efekta.com';
let _dnrOk = false; // DNR (Chrome/desktop/Lemur) conseguiu reescrever Origin? senao usamos fallback via aba
async function setupOriginOverride() {
  try {
    if (api.declarativeNetRequest && api.declarativeNetRequest.updateSessionRules) {
      await api.declarativeNetRequest.updateSessionRules({
        removeRuleIds: [9101],
        addRules: [{
          id: 9101, priority: 1,
          action: { type: 'modifyHeaders', requestHeaders: [
            { header: 'origin', operation: 'set', value: EF_ORIGIN },
            { header: 'referer', operation: 'set', value: EF_ORIGIN + '/' },
          ] },
          condition: { urlFilter: '||better.efekta.com', tabIds: [-1], resourceTypes: ['xmlhttprequest'] },
        }],
      });
      _dnrOk = true;
      return;
    }
  } catch (e) { /* DNR indisponivel (ex: alguns navegadores Android) -> fallback via aba no execRelay */ }
  try {
    if (api.webRequest && api.webRequest.onBeforeSendHeaders) {
      api.webRequest.onBeforeSendHeaders.addListener((details) => {
        if (details.tabId !== -1) return {};
        const hs = details.requestHeaders || [];
        let setO = false, setR = false;
        for (const h of hs) { const n = h.name.toLowerCase(); if (n === 'origin') { h.value = EF_ORIGIN; setO = true; } else if (n === 'referer') { h.value = EF_ORIGIN + '/'; setR = true; } }
        if (!setO) hs.push({ name: 'Origin', value: EF_ORIGIN });
        if (!setR) hs.push({ name: 'Referer', value: EF_ORIGIN + '/' });
        return { requestHeaders: hs };
      }, { urls: ['https://*.better.efekta.com/*'] }, ['blocking', 'requestHeaders']);
    }
  } catch (e) { /* */ }
}
setupOriginOverride();

// ---------- fetch direto no SW (Origin corrigido pela regra acima; catalyst vai sozinho) ----------
async function swFetch(url, opts) {
  opts = opts || {};
  try {
    const init = { method: opts.method || 'GET', credentials: opts.credentials || 'include', headers: opts.headers || {} };
    if (opts.body != null) init.body = opts.body;
    const r = await fetch(url, init);
    if (opts.binary) { const ab = await r.arrayBuffer(); const u = new Uint8Array(ab); let s = ''; for (let i = 0; i < u.length; i++) s += String.fromCharCode(u[i]); return { status: r.status, b64: btoa(s) }; }
    const t = await r.text();
    return { status: r.status, text: t };
  } catch (e) { return { status: 0, text: '', error: String(e && e.message || e) }; }
}

// ---------- fallback: fetch DENTRO de uma aba do Efekta (origem first-party, dispensa DNR) ----------
// Usado quando declarativeNetRequest nao esta disponivel (ex: alguns navegadores Android Chromium).
function _doFetchInPage(url, opts) {
  return (async () => {
    try {
      const init = { method: opts.method || 'GET', credentials: opts.credentials || 'include', headers: opts.headers || {} };
      if (opts.body != null) init.body = opts.body;
      const r = await fetch(url, init);
      if (opts.binary) { const ab = await r.arrayBuffer(); const u = new Uint8Array(ab); let s = ''; for (let i = 0; i < u.length; i++) s += String.fromCharCode(u[i]); return { status: r.status, b64: btoa(s) }; }
      const t = await r.text();
      return { status: r.status, text: t };
    } catch (e) { return { status: 0, text: '', error: String(e && e.message || e) }; }
  })();
}
async function _liveEfektaTab() {
  try { const tabs = await new Promise((r) => api.tabs.query({ url: 'https://*.better.efekta.com/*' }, r)); return (tabs && tabs[0]) ? tabs[0].id : null; } catch (e) { return null; }
}
async function tabFetch(url, opts) {
  const tabId = await _liveEfektaTab();
  if (!tabId || !api.scripting) return null;
  try { const out = await api.scripting.executeScript({ target: { tabId }, func: _doFetchInPage, args: [url, opts] }); return (out && out[0] && out[0].result) || null; } catch (e) { return null; }
}

// ---------- executa 1 request pedido pelo hub, injetando os tokens locais ----------
async function execRelay(req) {
  try {
    const { accessToken, accountJwt } = await sget(['accessToken', 'accountJwt']);
    const headers = {};
    const a = req.auth;
    if (a === 'learn') { headers['accept'] = 'application/json'; if (accessToken) headers['authorization'] = 'Bearer ' + accessToken; if (accountJwt) headers['x-ef-access'] = accountJwt; }
    else if (a === 'study' || a === 'account') { headers['accept'] = 'application/json, text/plain, */*'; if (accountJwt) headers['authorization'] = 'Bearer ' + accountJwt; }
    else if (a && typeof a === 'object' && a.bearer) { headers['authorization'] = 'Bearer ' + a.bearer; }
    if (req.body != null) headers['content-type'] = 'application/json';
    const opts = { method: req.method, headers, body: req.body, binary: req.binary, credentials: (a === 'none' ? 'omit' : 'include') };
    // Sem DNR (Origin nao reescrito): tenta rodar numa aba do Efekta (first-party) antes do SW.
    if (!_dnrOk) { const viaTab = await tabFetch(req.url, opts); if (viaTab && viaTab.status) return { id: req.id, status: viaTab.status, text: viaTab.text, b64: viaTab.b64, error: viaTab.error }; }
    const out = await swFetch(req.url, opts);
    return { id: req.id, status: out.status, text: out.text, b64: out.b64, error: out.error };
  } catch (e) { return { id: req.id, status: 0, error: String(e && e.message || e) }; }
}

// ---------- loop do rele: poll no hub, executa, devolve ----------
let _relaying = false;
async function startRelay() {
  if (_relaying) return; _relaying = true;
  let lastResult = null;
  try {
    for (;;) {
      const { extToken, acct } = await sget(['extToken', 'acct']);
      if (!extToken) break;
      const HUB = await getHub();
      let data = null;
      try {
        const r = await fetch(HUB + '/api/speak/ext/rpc', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ext_token: extToken, result: lastResult, acct: acct || null }) });
        if (r.status === 401) { await sset({ extToken: null, connected: false }); break; }
        data = await r.json().catch(() => null);
      } catch (e) { await sleep(2500); continue; }
      lastResult = null;
      if (data && data.action === 'fetch' && data.req) {
        lastResult = await execRelay(data.req);
      }
      // action idle -> repolla (o long-poll ja segurou ~12s)
    }
  } finally { _relaying = false; }
}

// ---------- vinculo com o hub (link_code -> ext_token) ----------
let _linking = false;
async function doLink() {
  if (_linking) return; _linking = true;
  try {
    const { linkCode, extToken, accessToken, accountJwt } = await sget(['linkCode', 'extToken', 'accessToken', 'accountJwt']);
    if (extToken) { startRelay(); return; }
    if (!linkCode || !accessToken || !accountJwt) return;
    const HUB = await getHub();
    const r = await fetch(HUB + '/api/speak/ext/link', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ link_code: linkCode, ua: navigator.userAgent }) });
    const j = await r.json().catch(() => ({}));
    if (r.ok && j.ext_token) { await sset({ extToken: j.ext_token, linkedAt: Date.now() }); startRelay(); }
  } catch (e) { /* */ } finally { _linking = false; }
}
async function maybeLink() { try { await doLink(); } catch (e) { /* */ } }

// ---------- abre/foca o hub ao capturar ----------
async function openOrFocusHub(hubOrigin) {
  const pats = ['https://openfuture.lol/*', 'https://*.openfuture.lol/*', 'https://*.openfuture-hub.pages.dev/*'];
  try {
    const tabs = await new Promise((r) => api.tabs.query({ url: pats }, r)) || [];
    if (tabs.length) { const t = tabs[0]; try { api.tabs.update(t.id, { active: true }); if (t.windowId != null && api.windows) api.windows.update(t.windowId, { focused: true }); } catch (e) { /* */ } return; }
  } catch (e) { /* */ }
  const hub = hubOrigin || 'https://openfuture.lol';
  try { api.tabs.create({ url: hub + '/?open=speak', active: true }); } catch (e) { /* */ }
}

// ---------- mensagens ----------
api.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    if (!msg || !msg.type) return sendResponse({ ok: false });
    if (msg.type === 'hub-origin') { if (msg.origin) await sset({ hubOrigin: msg.origin }); sendResponse({ ok: true }); return; }
    if (msg.type === 'link-code') { await sset({ linkCode: msg.code }); await maybeLink(); const s = await sget(['extToken']); sendResponse({ ok: true, linked: !!s.extToken }); return; }
    if (msg.type === 'login-start') {
      // (re)login em andamento (Azure/captcha) -> descarta tokens da conta anterior e NAO redireciona
      // ate capturar os novos. Evita mandar pro hub com token velho antes do captcha.
      await sset({ accessToken: null, accountJwt: null, acct: null, connected: false });
      sendResponse({ ok: true });
      return;
    }
    if (msg.type === 'speak-page') {
      const cat = await readCatalyst();
      if (cat) await sset({ catalyst: cat });
      const tk = await sget(['accountJwt', 'accessToken', 'acct', 'redirectedAcct', 'hubOrigin']);
      const captured = !!(tk.accountJwt && tk.accessToken);
      if (captured) {
        await sset({ connected: true }); await maybeLink();
        // redireciona UMA vez por conta; se trocou de conta, acct muda e redireciona de novo (nunca com token velho)
        if (tk.acct && tk.acct !== tk.redirectedAcct) {
          await sset({ redirectedAcct: tk.acct });
          await openOrFocusHub(tk.hubOrigin);
        }
      }
      sendResponse({ ok: true, captured });
      return;
    }
    if (msg.type === 'status') {
      const s = await sget(['connected', 'accountJwt', 'accessToken', 'catalyst', 'extToken']);
      sendResponse({ ok: true, version: '2.2.0', connected: !!s.connected, tokens: !!(s.accountJwt && s.accessToken), catalyst: !!s.catalyst, linked: !!s.extToken });
      return;
    }
    if (msg.type === 'debug') {
      const cat = await readCatalyst();
      const tk = await sget(['accountJwt', 'accessToken', 'hubOrigin', 'connected', 'extToken', 'tokAt']);
      let allCat = [];
      try { allCat = await new Promise((r) => api.cookies.getAll({ domain: 'better.efekta.com' }, r)) || []; } catch (e) { /* */ }
      sendResponse({
        ok: true, version: '2.2.0',
        catalyst: !!cat, catLen: cat ? cat.length : 0,
        tokens: !!(tk.accountJwt && tk.accessToken), accessToken: !!tk.accessToken, accountJwt: !!tk.accountJwt,
        jwtLen: tk.accountJwt ? tk.accountJwt.length : 0, accLen: tk.accessToken ? tk.accessToken.length : 0,
        linked: !!tk.extToken, relaying: _relaying, dnr: _dnrOk,
        cookieNames: allCat.map((c) => c.name + '@' + (c.domain || '')).slice(0, 25),
        hubOrigin: tk.hubOrigin || null,
      });
      return;
    }
    sendResponse({ ok: false });
  })();
  return true;
});

// ao instalar/iniciar, injeta o bridge nas abas do hub ja abertas (deteccao sem precisar recarregar)
function injectHubTabs() {
  try {
    api.tabs.query({ url: ['https://openfuture.lol/*', 'https://*.openfuture.lol/*', 'https://*.openfuture-hub.pages.dev/*'] }, (tabs) => {
      for (const t of (tabs || [])) { try { api.scripting.executeScript({ target: { tabId: t.id }, files: ['hub-bridge.js'] }); } catch (e) { /* */ } }
    });
  } catch (e) { /* */ }
}
api.runtime.onInstalled && api.runtime.onInstalled.addListener(injectHubTabs);
api.runtime.onStartup && api.runtime.onStartup.addListener(injectHubTabs);

// retoma o rele se o service worker reiniciar
api.alarms && api.alarms.create('keepalive', { periodInMinutes: 1 });
api.alarms && api.alarms.onAlarm.addListener(async () => { const { extToken } = await sget(['extToken']); if (extToken) startRelay(); });
// tenta retomar no boot
maybeLink();
