/* Content script em *.better.efekta.com.
 * - Em pagina de LOGIN/CAPTCHA (Azure/catalyst-enter/oauth): avisa 'login-start' -> o background
 *   descarta os tokens da conta anterior e NAO redireciona (evita mandar pro hub com token velho).
 * - Em pagina do APP (learn.../gap): pinga 'speak-page' -> o background captura e, se for conta NOVA,
 *   redireciona pro hub. Os tokens sao capturados pelo webRequest (nao aqui).
 */
(function () {
  var api = (typeof browser !== 'undefined') ? browser : chrome;
  var url = location.href;
  var isLogin = /(^|\/\/)(global\.accounts|catalyst-enter)\.better\.efekta\.com/.test(url) || /\/login\/|\/oauth2\/|\/authorize|\/enter(\?|$)/.test(url);

  if (isLogin) { try { api.runtime.sendMessage({ type: 'login-start', url: url }); } catch (e) { /* */ } return; }

  var shown = false;
  function badge(text, ok) {
    if (shown) return; shown = true;
    try {
      var d = document.createElement('div');
      d.textContent = text;
      d.style.cssText = 'position:fixed;z-index:2147483647;right:16px;bottom:16px;background:' +
        (ok ? '#1e1a2e' : '#2a1a1a') + ';color:#fff;font:600 13px system-ui;padding:10px 14px;border-radius:10px;' +
        'border:1px solid ' + (ok ? '#8b7cff66' : '#ff7a8a66') + ';box-shadow:0 10px 30px #0008;max-width:280px';
      (document.body || document.documentElement).appendChild(d);
      setTimeout(function () { try { d.remove(); } catch (e) {} }, 6000);
    } catch (e) { /* */ }
  }

  function ping() {
    try {
      api.runtime.sendMessage({ type: 'speak-page', url: url }, function (r) {
        if (r && r.captured) { badge('Speak conectado ao OpenFuture ✓', true); clearInterval(iv); }
      });
    } catch (e) { /* */ }
  }
  ping();
  var n = 0;
  var iv = setInterval(function () { if (++n > 40) { clearInterval(iv); return; } ping(); }, 2000);
})();
